# FastFps v1.0.0
Forge 1.9 / 12.16.1.1887. Arquitetura focada em estabilidade durante movimento rápido e +16 render distance.
Princípios: NEVER WAIT, budgets por frame, protected mode, predictive loading, priority queue, deduplicação por generation, sections 16x16x16, cache de região, culling e pooling.
Os hooks que dependem de mappings internos do renderer 1.9 são pontos de integração e devem ser validados no MDK real; não são declarados como magicamente completos.
